<?php 
    header("location: mahasiswa");
    die();
?>